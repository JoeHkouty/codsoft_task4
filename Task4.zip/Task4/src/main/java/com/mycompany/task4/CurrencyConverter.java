
package com.mycompany.task4;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONException;
import org.json.JSONObject;

public class CurrencyConverter {
    private static final String API_URL = "https://api.currencyapi.com/v3/latest?apikey=cur_live_dSSuBjGxivXwVSxgVLn7dWIM7IHtbTMJFySVWXiT";
    
    @SuppressWarnings({"UseSpecificCatch", "CallToPrintStackTrace", "ConvertToTryWithResources"})
    public double convertCurrency(String baseCurrency, String targetCurrency, double amount) {
        
        try {
            URL url = new URL(API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            
            System.out.println("API Response: " + response.toString());

            JSONObject jsonObject = new JSONObject(response.toString());
            JSONObject ratesObject = jsonObject.optJSONObject("data");
            if (ratesObject == null) {
                throw new JSONException("Missing 'data' field in the JSON response");
            }
            
            double baseRate = ratesObject.getJSONObject(baseCurrency.toUpperCase()).getDouble("value");
            double targetRate = ratesObject.getJSONObject(targetCurrency.toUpperCase()).getDouble("value");
            System.out.println(baseRate +"\n");
            System.out.println(targetRate);
            return amount * (targetRate / baseRate);

        } catch (Exception e) {
            e.printStackTrace();
            return -1; // Error indicator
        }
    }
}
